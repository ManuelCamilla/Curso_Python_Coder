from setuptools import setup

setup(
    name="Segunda pre-entrega+Camilla",
    version="1.0",
    description="Paquete para modelar compras de Cartas Pokemon.",
    author="Manuel Camilla Fuentes",
    author_email="manuel.camilla@gmail.com",
    packages=["Paquete"]
)